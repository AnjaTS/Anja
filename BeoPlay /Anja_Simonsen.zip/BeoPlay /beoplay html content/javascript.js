// JavaScript Document
$(document).ready(function(){
    $("#click").click(function(){
        $("#modal-box").slideUp(700);
    });
});